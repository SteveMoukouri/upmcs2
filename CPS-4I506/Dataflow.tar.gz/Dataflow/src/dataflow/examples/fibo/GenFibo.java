package dataflow.examples.fibo;

import java.math.BigInteger;

import dataflow.core.Composite;
import dataflow.core.IntEvent;
import dataflow.core.IntEventReceiverService;
import dataflow.core.Relay;
import dataflow.core.RequireIntEventReceiverService;
import dataflow.examples.basics.GenInt;
import dataflow.operators.Add;

/*
 * 
 * Exercice 2 -- Question 4
 * 
 * A compléter  
 * 
 */


public class GenFibo implements Composite,
			/* require */
			RequireIntEventReceiverService {

	private Add plus;
	private Relay rel1;
	private Relay rel2;

	public GenFibo() {
		plus = new Add();
		rel1 = new Relay();
		rel2= new Relay();
		plus.bindIntEventReceiverService(rel1);
		rel1.bindIntEventReceiverService(plus);
		rel1.bindIntEventReceiverService(rel2);
		rel2.bindIntEventReceiverService(plus);
		rel1.onIntEvent(new IntEvent(BigInteger.valueOf(0)));
		rel2.onIntEvent(new IntEvent(BigInteger.valueOf(1)));
	}	
	
	@Override
	public void bindIntEventReceiverService(IntEventReceiverService serv) {
		plus.bindIntEventReceiverService(serv);
	}
		
	@Override
	public void activate() {
		rel2.activate();
		rel1.activate();
		plus.activate();
	}

}
