package dataflow.examples.fact;

import dataflow.core.Printer;

public class GenFacTest {

	public static void main(String[] args) {
		GenFact fact = new GenFact();
		Printer print = new Printer();
		fact.bindIntEventReceiverService(print);
		for (int i = 0; i < 5; i++) {
			fact.activate();
			print.activate();
		}
	}

}
