package dataflow.examples.primes;

import java.math.BigInteger;

import dataflow.core.IntEvent;
import dataflow.core.IntEventReceiverService;
import dataflow.generators.SimpleGenerator;

/*
 * 
 * Exercice 3 -- Question 5
 * 
 * A compléter
 * 
 */

public class PrimeFilter extends SimpleGenerator 
		implements /* provide */
			       IntEventReceiverService {

	private BigInteger testBI;
	private BigInteger eventBI;
	private PrimeFilter next;
	
	public PrimeFilter() {
		this.testBI = null;
		this.eventBI = null;
	}
	
	@Override
	public void onIntEvent(IntEvent event) {
		eventBI = event.getValue();
	}
	
	@Override
	public void bindIntEventReceiverService(IntEventReceiverService serv) {
		if (testBI != null)
			next.bindIntEventReceiverService(serv);
		else 
			receivers.add(serv);
	}

	@Override
	public void activate() {
		if (eventBI == null) 
			throw new Error("Activated before a value was sent.");
		if (testBI == null) {
			PrimeFilter newLast = new PrimeFilter();
			this.send(new IntEvent(eventBI));
			for (IntEventReceiverService s : this.receivers)
				newLast.bindIntEventReceiverService(s);
			this.receivers.clear();
			this.next = newLast;
			bindIntEventReceiverService(next);
			this.testBI = eventBI;
		}
		else {
			if (eventBI.mod(testBI) != BigInteger.ZERO) {
				this.send(new IntEvent(eventBI));
				this.eventBI = null;
				next.activate();
			}
		}
	}
	
}
