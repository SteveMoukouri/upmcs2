package dataflow.core;

public interface Component extends ActivatorService {
	/* marker interface */
}
