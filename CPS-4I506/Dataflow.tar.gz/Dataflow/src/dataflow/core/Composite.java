package dataflow.core;

public interface Composite extends Component {
	/* marker interface */
}
