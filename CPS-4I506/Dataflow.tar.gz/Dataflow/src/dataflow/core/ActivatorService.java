package dataflow.core;

public interface ActivatorService {
	public void activate();
}
