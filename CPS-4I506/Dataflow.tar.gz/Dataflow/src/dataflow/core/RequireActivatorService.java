package dataflow.core;


public interface RequireActivatorService {
	public void bindActivatorService(ActivatorService service);
}
