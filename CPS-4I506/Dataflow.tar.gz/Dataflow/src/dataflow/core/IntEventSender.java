package dataflow.core;


public interface IntEventSender {
	public void send(IntEvent intEvent);
}
