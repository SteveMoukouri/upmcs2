package dataflow.core;


public interface IntEventReceiverService {
	public void onIntEvent(IntEvent event);
}
