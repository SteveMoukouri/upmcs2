package dataflow.core;


public interface RequireIntEventReceiverService {
	void bindIntEventReceiverService(IntEventReceiverService serv);
}
